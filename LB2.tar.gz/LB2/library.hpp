class library {

public:
	std::multimap<std::string,std::string> name_book;
	std::multimap<std::string,std::string> my_books;
	void book_search();
	void all_books();
	void add_book();
	void buff_books();
};
